﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frontend
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void ReservateButtom_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void LogInButton_Click(object sender, EventArgs e)
        {
            Business.LoginBusiness login = new Business.LoginBusiness(LoginUsernameTextBox.Text, LoginPasswordTextBox.Text);
            try
            {
                if (login.Login())
                {
                    tabControl1.SelectedTab = tabPage2;
                }
            }
            catch (Business.UserNotFoundException exc)
            {
                MessageBox.Show(exc.Message);
            }
            catch (Business.PasswordNotMatchingException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void checkBoxPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxPassword.Checked)
            {
                LoginPasswordTextBox.UseSystemPasswordChar = false;
            }
            else
            {
                LoginPasswordTextBox.UseSystemPasswordChar = true;
            }
        }

        private void BackButtom_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void backButtonSrc_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
        }

        private void ProfileButtonSrc_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage5;
        }

        private void BackFromMenu_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage6;
        }

        private void checkBoxPic_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxPic.Checked)
            {
                pictureBoxBulgaria.Visible = true; 
            }
            else
            {
                pictureBoxBulgaria.Visible = false;
            }
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage4;
            LoginUsernameTextBox.Text = "";
            LoginPasswordTextBox.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }
    }
}

