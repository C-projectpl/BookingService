﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using frontend.Data;

namespace frontend.Business
{
    class SearchBusiness
    {
        public int hotel_id { get; set; }
        public int roomType { get; set; }
        public DateTime arrivingDate { get; set; }
        public DateTime departingDate { get; set; }

        public SearchBusiness(int hotelId, int type, DateTime start, DateTime end)
        {
            hotel_id = hotelId;
            roomType = type;
            arrivingDate = start;
            departingDate = end;
        }

        public List<int> Search()
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                var freeRoomsId = dbContext.rooms
                    .Where(room => room.hotel_id == hotel_id && room.type == roomType)
                    .Select(room => room.id).ToList();
                var busyRooms = dbContext.reservations
                    .Where(reservation => (reservation.date_from < arrivingDate && reservation.date_to > arrivingDate) || (reservation.date_from > arrivingDate && reservation.date_from < departingDate))
                    .Select(reservation => reservation.room_id).ToList();
                for (int i = 0; i < busyRooms.Count; i++)
                {
                    if (freeRoomsId.Contains(busyRooms[i]))
                    {
                        freeRoomsId.Remove(busyRooms[i]);
                    }
                }
                List<int> freeRooms = new List<int>();
                foreach (int roomId in freeRoomsId)
                {
                    int roomNumber = dbContext.rooms.Where(room => room.id == roomId).Select(room => room.room_number).First();
                    freeRooms.Add(roomNumber);
                }

                return freeRooms;
            }
        }
    }
}
