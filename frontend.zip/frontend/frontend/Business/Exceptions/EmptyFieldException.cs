﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frontend.Business
{
    internal class EmptyFieldException : Exception
    {
        public EmptyFieldException() : base("There should not be empty fields!")
        {

        }
    }
}
