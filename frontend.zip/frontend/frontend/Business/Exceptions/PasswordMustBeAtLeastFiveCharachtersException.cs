﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frontend.Business
{
    internal class PasswordMustBeAtLeastFiveCharachtersException : Exception
    {
        public PasswordMustBeAtLeastFiveCharachtersException() : base("Password must be at least 5 charachters long!")
        {
        }
    }
}
