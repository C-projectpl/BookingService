﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using frontend.Data;
using System.Security.Cryptography;

namespace frontend.Business
{
    class ProfileBusiness
    {
        public int curID { get; set; }
        public ProfileBusiness(int user_id)
        {
            this.curID = user_id;
        }
        //USERNAME
        public void ShowUsername()
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                var uName = dbContext.users.FirstOrDefault(e => e.id == curID);
                Console.WriteLine(uName.username);
            }

        }
        public void ChangeUsername(string username)
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                if (username == "")
                {
                    throw new EmptyFieldException();
                }
                if (dbContext.users.Any(e => e.username == username))
                {
                    throw new EmptyFieldException();
                }
                var new_username = dbContext.users.FirstOrDefault(e => e.id == curID);
                new_username.username = username;
                dbContext.SaveChanges();
            }
        }
        //FIRST NAME
        public void ShowFirstName()
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                var fName = dbContext.user_info.FirstOrDefault(e => e.user_id == curID);
                Console.WriteLine(fName.first_name);
            }

        }
        public void ChangeFirstName(string fName)
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                if (fName == "")
                {
                    throw new EmptyFieldException();
                }
                var new_fName = dbContext.user_info.FirstOrDefault(e => e.user_id == curID);
                new_fName.first_name = fName;
                dbContext.SaveChanges();
            }
        }
        //LAST NAME
        public void ShowLastName()
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                var lName = dbContext.user_info.FirstOrDefault(e => e.user_id == curID);
                Console.WriteLine(lName.last_name);
            }

        }
        public void ChangeLastName(string lName)
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                if (lName == "")
                {
                    throw new EmptyFieldException();
                }
                var new_lName = dbContext.user_info.FirstOrDefault(e => e.user_id == curID);
                new_lName.last_name = lName;
                dbContext.SaveChanges();
            }
        }
        //PHONE NUMBER
        public void ShowPhoneNumber()
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                var phoneNumber = dbContext.user_info.FirstOrDefault(e => e.user_id == curID);
                Console.WriteLine(phoneNumber.phone_number);
            }

        }
        public void ChangePhoneNumber(string phoneNumber)
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                if (phoneNumber[0] != '0')
                {
                    throw new PhoneNumberMustStartWithZeroException();
                }
                if (phoneNumber.Length != 10)
                {
                    throw new PhoneMustHaveTenDigitsException();
                }
                var new_phoneNumber = dbContext.user_info.FirstOrDefault(e => e.user_id == curID);
                new_phoneNumber.phone_number = phoneNumber;
                dbContext.SaveChanges();
            }
        }
        //EMAIL
        public void ShowEmail()
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                var email = dbContext.user_info.FirstOrDefault(e => e.user_id == curID);
                Console.WriteLine(email.e_mail);
            }
        }
        public void ChangeEmail(string email)
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {

                if (!(email.Contains('@') && email.Contains('.')))
                {
                    throw new InvalidEmailException();
                }
                if (dbContext.user_info.Any(e => e.e_mail == email))
                {
                    throw new EmptyFieldException();
                }
                var new_email = dbContext.user_info.FirstOrDefault(e => e.user_id == curID);
                new_email.e_mail = email;
                dbContext.SaveChanges();
            }
        }
        //Password
        public void ChangePassword(string oldPassword, string newPassword, string confirmNewPassword)
        {
            using (booking_servicesEntities dbContext = new booking_servicesEntities())
            {
                var pass = dbContext.users.FirstOrDefault(e => e.id == curID);
                if (!HashExtractor(pass.password, oldPassword))
                {
                    throw new PasswordNotMatchingException();
                }
                if (newPassword == oldPassword)
                {
                    throw new EmptyFieldException();
                }
                if (newPassword.Length < 5)
                {
                    throw new PasswordMustBeAtLeastFiveCharachtersException();
                }
                if (newPassword != confirmNewPassword)
                {
                    throw new EmptyFieldException();
                }
                pass.password = Hasher(newPassword);
                dbContext.SaveChanges();
            }

        }
        private bool HashExtractor(string dbPassword, string inputPassword)
        {
            byte[] hashbytes = Convert.FromBase64String(dbPassword);
            byte[] saltExtracted = new byte[16];
            Array.Copy(hashbytes, 20, saltExtracted, 0, 16);

            var loginHasher = new Rfc2898DeriveBytes(inputPassword, saltExtracted, 1000);
            byte[] hashExtracted = loginHasher.GetBytes(20);
            bool difference = false;

            for (int i = 0; i < 20; i++)
            {
                if (hashbytes[i] != hashExtracted[i])
                {
                    difference = true;
                }
            }
            return !difference;
        }
        public string Hasher(string password)
        {
            byte[] salt = new byte[16];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(salt);
            }
            using (var hasher = new Rfc2898DeriveBytes(password, salt, 1000))
            {
                byte[] hashedPass = hasher.GetBytes(20);
                byte[] saltyHashedPassword = new byte[36];
                Array.Copy(hashedPass, 0, saltyHashedPassword, 0, 20);
                Array.Copy(salt, 0, saltyHashedPassword, 20, 16);
                string base64Password = Convert.ToBase64String(saltyHashedPassword);

                return base64Password;
            }
        }
    }
}
