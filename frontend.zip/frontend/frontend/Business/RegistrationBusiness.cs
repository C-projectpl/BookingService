﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using frontend.Data;
using System.Security.Cryptography;


namespace frontend.Business
{
    public class RegistrationBusiness
    {
        public user_info newUserInfo { get; set; }
        public user newUser { get; set; }

        public RegistrationBusiness(string fName, string lName, string phone, string email, string username, string pass)
        {
            if (pass.Length < 5)
            {
                throw new PasswordMustBeAtLeastFiveCharachtersException();
            }
            if (!(email.Contains('@') && email.Contains('.')))
            {
                throw new InvalidEmailException();
            }
            if(phone[0]!='0')
            {
                throw new PhoneNumberMustStartWithZeroException();
            }
            if (phone.Length != 10)
            {
                throw new PhoneMustHaveTenDigitsException();
            }
            if(fName=="" || lName == "" || username == "")
            {
                throw new EmptyFieldException();
            }

            newUserInfo = new user_info();
            newUser = new user();
            newUserInfo.first_name = fName;
            newUserInfo.last_name = lName;
            newUserInfo.phone_number = phone;
            newUserInfo.e_mail = email;
            newUser.username = username;
            newUser.password = Hasher(pass);
            newUserInfo.id = newUser.id;
        }
        public void Register()
        {
            using (booking_servicesEntities register = new booking_servicesEntities())
            {
                register.user_info.Add(newUserInfo);
                register.users.Add(newUser);
                register.SaveChanges();



            }
        }
        public string Hasher(string password)
        {
            byte[] salt = new byte[16];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(salt);
            }

            using (var hasher = new Rfc2898DeriveBytes(password, salt, 1000))
            {
                byte[] hashedPass = hasher.GetBytes(20);
                byte[] saltyHashedPassword = new byte[36];
                Array.Copy(hashedPass, 0, saltyHashedPassword, 0, 20);
                Array.Copy(salt, 0, saltyHashedPassword, 20, 16);
                string base64Password = Convert.ToBase64String(saltyHashedPassword);

                return base64Password;
            }
        }
    }
}
