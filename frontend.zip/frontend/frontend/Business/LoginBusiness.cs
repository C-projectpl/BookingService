﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;
using frontend.Data;

namespace frontend.Business
{
    class LoginBusiness
    {
        public string username { get; set; }
        public string password { get; set; }

        public LoginBusiness(string username, string password)
        {
            this.username = username;
            this.password = password;
        }
        public bool Login()
        {
            bool findUser = false;

            using (booking_servicesEntities userContext = new booking_servicesEntities())
            {
                foreach (var user in userContext.users)
                {
                    if (user.username.Equals(username))
                    {
                        if (HashExtractor(user.password))
                        {
                            findUser = true;
                            break;
                        }
                        else
                        {
                            throw new PasswordNotMatchingException();
                        }
                    }
                }
            }
            if (!findUser)
            {
                throw new UserNotFoundException();
            }
            return findUser;
        }
        private bool HashExtractor(string password)
        {
            byte[] hashbytes = Convert.FromBase64String(password);
            byte[] saltExtracted = new byte[16];
            Array.Copy(hashbytes, 20, saltExtracted, 0, 16);

            var loginHasher = new Rfc2898DeriveBytes(this.password, saltExtracted, 1000);
            byte[] hashExtracted = loginHasher.GetBytes(20);
            bool difference = false;

            for (int i = 0; i < 20; i++)
            {
                if (hashbytes[i] != hashExtracted[i])
                {
                    difference = true;
                }
            }
            return !difference;
        }
    }
}
